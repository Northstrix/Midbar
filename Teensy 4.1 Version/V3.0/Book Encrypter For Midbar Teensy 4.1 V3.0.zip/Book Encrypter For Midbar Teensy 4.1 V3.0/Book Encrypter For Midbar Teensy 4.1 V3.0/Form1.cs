/*
Midbar
Distributed under the MIT License
� Copyright Maxim Bortnikov 2024
For more information please visit
https://sourceforge.net/projects/midbar/
https://github.com/Northstrix/Midbar
Required libraries:
https://github.com/zhouyangchao/AES
https://github.com/peterferrie/serpent
https://github.com/ddokkaebi/Blowfish
https://github.com/Northstrix/DES_and_3DES_Library_for_MCUs
https://github.com/ulwanski/sha512
https://github.com/adafruit/Adafruit-ST7735-Library
https://github.com/adafruit/Adafruit-GFX-Library
https://github.com/adafruit/Adafruit_BusIO
https://github.com/intrbiz/arduino-crypto
*/
using System;
using System.Collections;
using System.IO;
using System.Reflection.Emit;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Engines;
using Org.BouncyCastle.Crypto.Modes;
using Org.BouncyCastle.Crypto.Paddings;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Security;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Book_Encrypter_For_Midbar_Teensy_4._1_V3._0
{
    public partial class Form1 : Form
    {
        protected static byte[] serp_key = { 128, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        protected static StringBuilder string_for_data = new StringBuilder();
        protected static int decract;
        protected static byte[] array_for_CBC_mode = new byte[16];
        protected static void incr_serp_key()
        {
            for (int i = 15; i >= 0; i--)
            {
                if (serp_key[i] == 255)
                {
                    serp_key[i] = 0;
                }
                else
                {
                    serp_key[i]++;
                    break;
                }
            }
        }


        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public static string ByteArrayToString(byte[] ba)
        {
            StringBuilder hex = new StringBuilder(ba.Length * 2);
            foreach (byte b in ba)
                hex.AppendFormat("{0:x2}", b);
            return hex.ToString();
        }
        static byte[] EncryptSerpent(byte[] inputBytes)
        {

            SerpentEngine serpentEngine = new SerpentEngine();
            serpentEngine.Init(true, new KeyParameter(serp_key));

            byte[] encryptedData = new byte[inputBytes.Length];

            serpentEngine.ProcessBlock(inputBytes, 0, encryptedData, 0);

            return encryptedData;
        }

        private string ReadFileContent(string filePath)
        {
            try
            {
                // Read the content of the selected file
                string fileContent = File.ReadAllText(filePath);
                return fileContent;
            }
            catch (Exception ex)
            {
                // Handle exceptions (e.g., file not found, access denied)
                return "Error reading file: " + ex.Message;
            }
        }
        static void SetKeyToSerpentFromString(string hexString)
        {
            // Check if the input string is a valid hexadecimal string
            if (hexString.Length % 2 != 0 || !System.Text.RegularExpressions.Regex.IsMatch(hexString, @"\A\b[0-9a-fA-F]+\b\Z"))
            {
                throw new ArgumentException("Invalid hexadecimal string.");
            }

            // Convert the hexadecimal string to a byte array
            byte[] byteArray = new byte[hexString.Length / 2];
            for (int i = 0; i < hexString.Length; i += 2)
            {
                serp_key[i / 2] = Convert.ToByte(hexString.Substring(i, 2), 16);
            }
        }

        static string get_data_from_entry(string prompt)
        {
            Form promptForm = new Form()
            {
                Width = 240,
                Height = 154,
                FormBorderStyle = FormBorderStyle.FixedDialog,
                Text = "Data Entry",
                StartPosition = FormStartPosition.CenterScreen,
                BackColor = ColorTranslator.FromHtml("#202020") // Set form background color
            };

            Color backgroundColor = ColorTranslator.FromHtml("#202020");
            Color foregroundColor = ColorTranslator.FromHtml("#EEEEEE");

            System.Windows.Forms.Label label = new System.Windows.Forms.Label()
            {
                Left = 8,
                Top = 5,
                Width = 230,
                Text = prompt,
                BackColor = backgroundColor,
                ForeColor = foregroundColor
            };

            System.Windows.Forms.TextBox textBox = new System.Windows.Forms.TextBox()
            {
                Left = 8,
                Top = 32,
                Width = promptForm.Width - 40,
                BackColor = backgroundColor,
                ForeColor = foregroundColor
            };

            System.Windows.Forms.Button okButton = new System.Windows.Forms.Button()
            {
                Text = "OK",
                Left = 8,
                Width = 60,
                Top = 70,
                Height = 35, // Set button height
                DialogResult = DialogResult.OK,
                BackColor = backgroundColor,
                ForeColor = foregroundColor
            };

            System.Windows.Forms.Button cancelButton = new System.Windows.Forms.Button()
            {
                Text = "Cancel",
                Left = 90,
                Width = 60,
                Top = 70,
                Height = 35, // Set button height
                DialogResult = DialogResult.Cancel,
                BackColor = backgroundColor,
                ForeColor = foregroundColor
            };

            okButton.Click += (sender, e) => { promptForm.Close(); };
            cancelButton.Click += (sender, e) => { promptForm.Close(); };

            promptForm.Controls.Add(label);
            promptForm.Controls.Add(textBox);
            promptForm.Controls.Add(okButton);
            promptForm.Controls.Add(cancelButton);

            promptForm.AcceptButton = okButton;
            promptForm.CancelButton = cancelButton;

            return promptForm.ShowDialog() == DialogResult.OK ? textBox.Text : "";
        }

        static bool Validate_book_encryption_key(string input)
        {
            // Use regular expression to check if the input is a valid hexadecimal string
            return Regex.IsMatch(input, "^[0-9a-fA-F]+$");
        }

        private void encryptBookToolStripMenuItem_Click(object sender, EventArgs e)
        {

            string encryptionKey = get_data_from_entry("Enter Encryption Key:");

            if (!string.IsNullOrEmpty(encryptionKey))
            {
                if (Validate_book_encryption_key(encryptionKey) && encryptionKey.Length == 64)
                {
                    SetKeyToSerpentFromString(encryptionKey);
                    OpenFileDialog openFileDialog = new OpenFileDialog();
                    openFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
                    openFileDialog.Title = "Select a Book You'd Like to Encrypt";

                    if (openFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        string filePath = openFileDialog.FileName;
                        string fileContent = ReadFileContent(filePath);

                        byte[] iv = new byte[16]; // Initialization vector

                        Random random = new Random();
                        for (int i = 0; i < 16; i++)
                        {
                            iv[i] = (byte)random.Next(256); // Fill iv array with random numbers.
                        }

                        // Assuming plt is a byte array representing the plaintext
                        encryptStringWithSerpentInCbc(fileContent, iv);
                        SaveStringToFile(string_for_data.ToString());
                    }
                }
                else
                {
                    MessageBox.Show("Invalid Encryption Key", "Error");
                }
            }

        }

        static void SaveStringToFile(string content)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "All Files (*.*)|*.*";
            saveFileDialog.FileName = "Enc Book"; // Default file name
            saveFileDialog.Title = "Save Encrypted Book";
            saveFileDialog.DefaultExt = ""; // Ensure no default extension

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = saveFileDialog.FileName;

                try
                {
                    // Append ".txt" to the file path to ensure no extension
                    File.WriteAllText(filePath, content);

                    Console.WriteLine("File saved successfully.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error saving file: {ex.Message}");
                }
            }
            else
            {
                Console.WriteLine("File saving canceled.");
            }
        }

        static void encryptStringWithSerpentInCbc(String input, byte[] iv)
        {
            string_for_data.Clear();
            decract = 0;
            encrypt_iv_for_serpnt_in_cbc_mode(iv);
            int strLen = input.Length + 1;
            char[] inputArr = new char[strLen];
            input.CopyTo(0, inputArr, 0, input.Length);

            int p = 0;
            while (strLen > p + 1)
            {
                split_by_sixteen_for_encryption(inputArr, p, strLen);
                p += 16;
            }
        }

        static void split_by_sixteen_for_encryption(char[] plaintext, int k, int strLen)
        {
            byte[] res = new byte[16];

            for (int i = 0; i < 16; i++)
                res[i] = 0;

            for (int i = 0; i < 16; i++)
            {
                if (i + k > strLen - 1)
                    break;
                res[i] = (byte)plaintext[i + k];
            }

            for (int i = 0; i < 16; i++)
                res[i] ^= array_for_CBC_mode[i];

            encrypt_with_serpent(res);
        }

        private static void encrypt_iv_for_serpnt_in_cbc_mode(byte[] iv)
        {
            for (int i = 0; i < 16; i++)
            {
                array_for_CBC_mode[i] = iv[i];
            }

            encrypt_with_serpent(iv);
        }

        static void encrypt_with_serpent(byte[] passToSerp)
        {
            byte[] ct2b = EncryptSerpent(passToSerp);
            incr_serp_key();

            for (int i = 0; i < 16; i++)
            {
                if (decract > 0)
                {
                    if (i < 16)
                    {
                        array_for_CBC_mode[i] = ct2b[i];
                    }
                }
            }
            string_for_data.Append(ByteArrayToHexString(ct2b));
            decract++;
        }

        protected static string ByteArrayToHexString(byte[] byteArray)
        {
            StringBuilder hexStringBuilder = new StringBuilder(byteArray.Length * 2);

            foreach (byte b in byteArray)
            {
                hexStringBuilder.AppendFormat("{0:X2}", b);
            }

            return hexStringBuilder.ToString();
        }

        private void quitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}